<?php

return [

    'time' => 'Uhrzeit',
    'Sunday' => 'Sonntag',
	'Monday' => 'Montag',
	'Tuesday' => 'Dienstag',
	'Wednesday' => 'Mittwoch',
	'Thursday' => 'Donnerstag',
	'Friday' => 'Freitag',
	'Saturday' => 'Samstag',
];

	